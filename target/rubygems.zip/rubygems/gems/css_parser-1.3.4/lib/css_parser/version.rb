module CssParser
  VERSION = "1.3.4"
end
