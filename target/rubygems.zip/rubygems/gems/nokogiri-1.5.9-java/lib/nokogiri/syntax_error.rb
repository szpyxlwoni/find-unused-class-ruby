module Nokogiri
  class SyntaxError < ::StandardError
  end
end
