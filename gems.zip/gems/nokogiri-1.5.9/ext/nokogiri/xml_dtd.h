#ifndef NOKOGIRI_XML_DTD
#define NOKOGIRI_XML_DTD

#include <nokogiri.h>

extern VALUE cNokogiriXmlDtd;

void init_xml_dtd();

#endif
